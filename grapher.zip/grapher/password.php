<?php
$password="lskjdnhflia7";
?>