<?php
$password="lskjdnhflia7";
$correctpass="lskjdnhflia7";
?>