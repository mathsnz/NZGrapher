<?php
$password="lskjdnhflia7";
?>