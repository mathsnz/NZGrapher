<?php
if(md5($_GET['c'])!='49374b11da5cdc612e1bccbd9e662f7a'){die('incorrect token');}
phpinfo();
?>