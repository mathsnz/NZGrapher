<?php
/**
 * Created by PhpStorm.
 * User: Alexander Morris
 * Date: 2/22/2018
 * Time: 8:37 PM
 */

$correctpass = md5($correctpass);
echo $correctpass;