<?php
echo file_get_contents(urldecode($_GET['dataset']));
?>
