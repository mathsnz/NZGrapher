NZGrapher is created by Jake Wills and these files are provided free of waranty, express or implied.
These files have been provided to you and your organisation... 
   please do not distrubute these files without the consent of the author.

### Install Requrements ###
- Web server running PHP with GD Library installed
- Read-Write permissions on the /imagetemp folder.

### Easy Update Requrements ###
- Read-Write permissions on the grapher folder.
- Folder needs to be called 'grapher'.

### Check it is Working ###
The best way to check that it has installed correctly is to change the graph type to pairs plot.
If this draws a graph and the text labels are showing then it has been correctly installed.

### Own Folders ###
If you want to set up a separate folder for datasets this can be done by copying the folder template 
folder and renaming it to whatever you want it to be called. 
The password can be set by changing the contents of the password.php file.

### Contact ###
If you have any questions please contact jwills@mathsnz.com